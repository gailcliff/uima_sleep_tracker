package com.example.sleeptracker;

public interface DailyMinCallback {
    void onDailyMinimumSet(int hours, int minutes);
}
